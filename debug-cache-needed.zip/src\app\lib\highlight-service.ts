import { getFeaturedHighlight } from "@/app/lib/featured-moments";
import {
  getDayHighlight,
  getDayHighlights,
  type DayHighlight,
} from "@/app/lib/wiki";

export type HighlightServiceResult = {
  highlight: DayHighlight;
  highlights: DayHighlight[];
};

const STOP_WORDS = new Set([
  "the",
  "a",
  "an",
  "of",
  "and",
  "in",
  "on",
  "at",
  "for",
  "to",
  "from",
  "with",
  "by",
  "into",
  "after",
  "before",
  "during",
  "over",
  "under",
  "as",
  "is",
  "was",
  "were",
  "be",
  "been",
  "this",
  "that",
  "these",
  "those",
]);

const DERIVATIVE_TERMS = new Set([
  "casualties",
  "casualty",
  "victims",
  "victim",
  "deaths",
  "death",
  "dead",
  "injured",
  "injury",
  "aftermath",
  "timeline",
  "perpetrators",
  "perpetrator",
  "hijackers",
  "hijacker",
  "memorial",
  "memorials",
  "reaction",
  "reactions",
  "response",
  "responses",
  "investigation",
  "investigations",
  "background",
  "legacy",
  "commemoration",
  "commemorations",
  "list",
  "lists",
  "category",
  "archive",
  "archives",
]);

function buildSafeFallback(): DayHighlight {
  return {
    type: "none",
    secondaryType: null,
    year: null,
    text: "No exact historical match was found for this date.",
    title: null,
    image: null,
    articleUrl: null,
  };
}

function isNonNullHighlight(
  value: DayHighlight | null | undefined
): value is DayHighlight {
  return !!value;
}

function normalizeText(value?: string | null) {
  return (value ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\([^)]*\)/g, " ")
    .replace(/[_/]+/g, " ")
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenize(value?: string | null) {
  return normalizeText(value)
    .split(" ")
    .map((token) => token.trim())
    .filter(Boolean);
}

function meaningfulTokens(value?: string | null) {
  return tokenize(value).filter((token) => {
    if (STOP_WORDS.has(token)) return false;
    if (token.length <= 1) return false;
    return true;
  });
}

function extractArticleSlug(articleUrl?: string | null) {
  if (!articleUrl) return "";

  try {
    const url = new URL(articleUrl);
    const parts = url.pathname.split("/").filter(Boolean);
    const slug = parts[parts.length - 1] ?? "";
    return normalizeText(slug);
  } catch {
    return "";
  }
}

function canonicalSlug(articleUrl?: string | null) {
  const slug = extractArticleSlug(articleUrl);
  if (!slug) return "";

  const tokens = meaningfulTokens(slug).filter(
    (token) => !DERIVATIVE_TERMS.has(token)
  );

  return tokens.join(" ");
}

function titleWordCount(item: DayHighlight) {
  return meaningfulTokens(item.title).length;
}

function getPenaltyScore(item: DayHighlight) {
  const combined = [
    normalizeText(item.title),
    normalizeText(item.text),
    canonicalSlug(item.articleUrl),
    extractArticleSlug(item.articleUrl),
  ]
    .filter(Boolean)
    .join(" ");

  let penalty = 0;

  for (const term of DERIVATIVE_TERMS) {
    if (combined.includes(term)) {
      penalty += 1;
    }
  }

  return penalty;
}

function getQualityScore(item: DayHighlight) {
  const title = (item.title ?? "").trim();
  const text = (item.text ?? "").trim();
  const words = titleWordCount(item);

  let score = 0;

  if (item.image) score += 8;
  if (item.articleUrl) score += 5;
  if (title) score += 4;
  if (text.length >= 60) score += 3;
  if (text.length >= 120) score += 2;

  if (words >= 2 && words <= 6) score += 4;
  if (words === 1) score -= 4;
  if (words >= 10) score -= 2;

  if (title.length > 0 && title.length <= 48) score += 2;
  if (title.length >= 90) score -= 2;

  score -= getPenaltyScore(item) * 6;

  return score;
}

function buildTopicTokenSet(item: DayHighlight) {
  const titleTokens = meaningfulTokens(item.title);
  const textTokens = meaningfulTokens(item.text).slice(0, 28);
  const slugTokens = meaningfulTokens(canonicalSlug(item.articleUrl));

  return new Set([...titleTokens, ...textTokens, ...slugTokens]);
}

function intersectionSize(a: Set<string>, b: Set<string>) {
  let count = 0;

  for (const value of a) {
    if (b.has(value)) count += 1;
  }

  return count;
}

function jaccardSimilarity(a: Set<string>, b: Set<string>) {
  if (a.size === 0 || b.size === 0) return 0;

  const intersection = intersectionSize(a, b);
  const union = new Set([...a, ...b]).size;

  if (union === 0) return 0;
  return intersection / union;
}

function sameImage(a?: string | null, b?: string | null) {
  if (!a || !b) return false;
  return a.trim() === b.trim();
}

function sameTitle(a?: string | null, b?: string | null) {
  const left = normalizeText(a);
  const right = normalizeText(b);

  return !!left && !!right && left === right;
}

function sameCanonicalSlug(a?: string | null, b?: string | null) {
  const left = canonicalSlug(a);
  const right = canonicalSlug(b);

  return !!left && !!right && left === right;
}

function isSameTopic(a: DayHighlight, b: DayHighlight) {
  if (sameTitle(a.title, b.title)) return true;
  if (sameCanonicalSlug(a.articleUrl, b.articleUrl)) return true;

  const tokensA = buildTopicTokenSet(a);
  const tokensB = buildTopicTokenSet(b);

  const overlap = intersectionSize(tokensA, tokensB);
  const similarity = jaccardSimilarity(tokensA, tokensB);

  if (sameImage(a.image, b.image) && overlap >= 3) {
    return true;
  }

  if (similarity >= 0.62) {
    return true;
  }

  if (overlap >= 6 && similarity >= 0.36) {
    return true;
  }

  if (overlap >= 8) {
    return true;
  }

  return false;
}

function exactKey(item: DayHighlight) {
  return [
    normalizeText(item.title),
    normalizeText(item.text),
    normalizeText(item.articleUrl),
    normalizeText(item.image),
  ].join("|");
}

function dedupeHighlights(items: DayHighlight[]) {
  const exactMap = new Map<string, DayHighlight>();

  for (const item of items) {
    const key = exactKey(item);
    const existing = exactMap.get(key);

    if (!existing) {
      exactMap.set(key, item);
      continue;
    }

    if (getQualityScore(item) > getQualityScore(existing)) {
      exactMap.set(key, item);
    }
  }

  const sorted = [...exactMap.values()].sort(
    (a, b) => getQualityScore(b) - getQualityScore(a)
  );

  const kept: DayHighlight[] = [];

  for (const candidate of sorted) {
    const alreadyCovered = kept.some((existing) =>
      isSameTopic(existing, candidate)
    );

    if (alreadyCovered) {
      continue;
    }

    kept.push(candidate);
  }

  return kept;
}

export async function ensureHighlightsForDay(
  day: string
): Promise<HighlightServiceResult> {
  const featured = getFeaturedHighlight(day);

  if (featured) {
    return {
      highlight: featured,
      highlights: [featured],
    };
  }

  try {
    const [listHighlights, singleHighlight] = await Promise.all([
      getDayHighlights(day),
      getDayHighlight(day),
    ]);

    const mergedCandidates = [
      ...listHighlights,
      ...(singleHighlight ? [singleHighlight] : []),
    ].filter(isNonNullHighlight);

    const merged = dedupeHighlights(mergedCandidates);

    const highlight = merged[0];

    if (!highlight) {
      const fallback = buildSafeFallback();
      return {
        highlight: fallback,
        highlights: [fallback],
      };
    }

    return {
      highlight,
      highlights: merged.length ? merged : [highlight],
    };
  } catch (error) {
    console.error("ensureHighlightsForDay error:", error);

    const fallback = buildSafeFallback();

    return {
      highlight: fallback,
      highlights: [fallback],
    };
  }
}