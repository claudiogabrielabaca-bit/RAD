"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

type SiteHeaderProps = {
  isLoggedIn?: boolean;
  username?: string;
};

export default function SiteHeader({
  isLoggedIn = false,
  username = "@username",
}: SiteHeaderProps) {
  const pathname = usePathname();
  const isDiscoverActive = pathname === "/";

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/[0.07] bg-black/72 backdrop-blur-xl">
      <div className="flex h-16 w-full items-center justify-end px-5 sm:px-6 lg:px-8">
        <nav className="flex items-center gap-2 sm:gap-3">
          <Link
            href="/"
            className={`inline-flex h-10 items-center rounded-[12px] px-4 text-[14px] font-medium tracking-[-0.01em] transition ${
              isDiscoverActive
                ? "text-white"
                : "text-white/72 hover:text-white"
            }`}
          >
            Discover
          </Link>

          {!isLoggedIn ? (
            <>
              <Link
                href="/login"
                className="inline-flex h-10 items-center rounded-[12px] px-4 text-[14px] font-medium text-white/82 transition hover:bg-white/[0.04] hover:text-white"
              >
                Log in
              </Link>

              <Link
                href="/register"
                className="inline-flex h-10 items-center rounded-[14px] bg-white px-4 text-[14px] font-semibold text-black transition hover:bg-white/92"
              >
                Register
              </Link>
            </>
          ) : (
            <Link
              href="/profile"
              className="inline-flex h-10 items-center rounded-[14px] border border-white/8 bg-white/[0.06] px-4 text-[14px] font-medium text-white transition hover:bg-white/[0.09]"
            >
              {username}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}