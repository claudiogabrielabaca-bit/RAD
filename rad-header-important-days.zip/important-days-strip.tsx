"use client";

import { useEffect, useState } from "react";
import DiscoverDayCard from "@/app/components/rad/discover-day-card";
import { loadDiscoverRandomDays } from "@/app/lib/home-page-discover";
import type { DiscoverCard } from "@/app/lib/rad-types";

export default function ImportantDaysStrip({
  onSelectDay,
  inHeader = false,
}: {
  onSelectDay: (day: string) => void;
  inHeader?: boolean;
}) {
  const [days, setDays] = useState<DiscoverCard[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      setLoading(true);
      const items = await loadDiscoverRandomDays(5, false);

      if (!cancelled) {
        setDays(items);
        setLoading(false);
      }
    }

    void run();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <section className={inHeader ? "mt-0" : "mt-14"}>
      <div className="mb-5">
        <div className="text-xl font-semibold text-zinc-100">
          Important Days
        </div>
        <div className="mt-1 text-sm text-zinc-400">
          A curated selection of defining moments from the modern era
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-5">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-[360px] animate-pulse rounded-[30px] border border-white/8 bg-white/[0.04]"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-5">
          {days.map((card, index) => (
            <DiscoverDayCard
              key={`${card.day}-${index}`}
              card={card}
              onSelect={(selectedDay) => onSelectDay(selectedDay)}
            />
          ))}
        </div>
      )}
    </section>
  );
}