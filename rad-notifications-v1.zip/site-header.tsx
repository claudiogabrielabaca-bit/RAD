"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import AuthModal, { type AuthView } from "@/app/components/rad/auth-modal";

type HeaderUser = {
  id: string;
  email: string;
  username: string;
  emailVerified?: boolean;
} | null;

export default function SiteHeader() {
  const pathname = usePathname();
  const router = useRouter();

  const [authView, setAuthView] = useState<AuthView>("login");
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<HeaderUser>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);

  const menuRef = useRef<HTMLDivElement | null>(null);

  const isDiscoverActive = pathname === "/";
  const isFeedActive = pathname === "/feed";

  useEffect(() => {
    let cancelled = false;

    async function loadMe() {
      try {
        setIsLoadingUser(true);

        const res = await fetch("/api/me", {
          credentials: "include",
          cache: "no-store",
        });

        if (!res.ok) {
          if (!cancelled) {
            setCurrentUser(null);
          }
          return;
        }

        const data = await res.json();

        const user =
          data && typeof data === "object" && "user" in data
            ? (data.user ?? null)
            : (data ?? null);

        if (!cancelled) {
          setCurrentUser(user);
        }
      } catch {
        if (!cancelled) {
          setCurrentUser(null);
        }
      } finally {
        if (!cancelled) {
          setIsLoadingUser(false);
        }
      }
    }

    loadMe();

    const handleAuthChanged = () => {
      loadMe();
    };

    window.addEventListener("rad-auth-changed", handleAuthChanged);

    return () => {
      cancelled = true;
      window.removeEventListener("rad-auth-changed", handleAuthChanged);
    };
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) return;

    function handlePointerDown(event: MouseEvent) {
      if (!menuRef.current) return;
      if (menuRef.current.contains(event.target as Node)) return;
      setMenuOpen(false);
    }

    function handleEscape(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setMenuOpen(false);
      }
    }

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [menuOpen]);

  const openLogin = () => {
    setAuthView("login");
    setIsAuthOpen(true);
  };

  const openRegister = () => {
    setAuthView("register");
    setIsAuthOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthOpen(false);
  };

  async function handleLogout() {
    try {
      await fetch("/api/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch {
      // noop
    } finally {
      setMenuOpen(false);
      setCurrentUser(null);
      window.dispatchEvent(new Event("rad-auth-changed"));
      router.push("/");
      router.refresh();
    }
  }

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-white/[0.07] bg-black/72 backdrop-blur-xl">
        <div className="flex h-16 w-full items-center justify-end px-5 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-8">
            <Link
              href="/"
              className={`inline-flex h-10 items-center text-[14px] font-semibold tracking-[-0.01em] transition ${
                isDiscoverActive
                  ? "text-white"
                  : "text-white/72 hover:text-white"
              }`}
            >
              Discover
            </Link>

            <Link
              href="/feed"
              className={`inline-flex h-10 items-center text-[14px] font-semibold tracking-[-0.01em] transition ${
                isFeedActive ? "text-white" : "text-white/72 hover:text-white"
              }`}
            >
              Feed
            </Link>

            {isLoadingUser ? (
              <div className="flex items-center gap-8">
                <span className="inline-flex h-6 w-[90px] animate-pulse rounded bg-white/[0.06]" />
                <span className="inline-flex h-6 w-[24px] animate-pulse rounded bg-white/[0.06]" />
              </div>
            ) : currentUser ? (
              <div ref={menuRef} className="relative flex items-center gap-8">
                <Link
                  href="/profile"
                  className="inline-flex h-10 items-center text-[14px] font-semibold text-white transition hover:text-white/80"
                >
                  @{currentUser.username}
                </Link>

                <button
                  type="button"
                  onClick={() => setMenuOpen((prev) => !prev)}
                  aria-label="Open account menu"
                  aria-expanded={menuOpen}
                  className="inline-flex h-10 items-center text-[20px] leading-none text-white/88 transition hover:text-white"
                >
                  <span className="relative -top-[3px] tracking-[0.08em]">
                    …
                  </span>
                </button>

                {menuOpen ? (
                  <div className="absolute right-0 top-[calc(100%+10px)] min-w-[180px] overflow-hidden rounded-[18px] border border-white/10 bg-[#111111]/95 p-2 shadow-[0_24px_60px_rgba(0,0,0,0.45)] backdrop-blur-xl">
                    <button
                      type="button"
                      onClick={handleLogout}
                      className="flex w-full items-center rounded-[12px] px-3 py-2.5 text-left text-sm text-red-200 transition hover:bg-red-500/10 hover:text-red-100"
                    >
                      Log out
                    </button>
                  </div>
                ) : null}
              </div>
            ) : (
              <div className="flex items-center gap-8">
                <button
                  type="button"
                  onClick={openLogin}
                  className="inline-flex h-10 items-center text-[14px] font-medium text-white/82 transition hover:text-white"
                >
                  Log in
                </button>

                <button
                  type="button"
                  onClick={openRegister}
                  className="inline-flex h-10 items-center text-[14px] font-semibold text-white transition hover:text-white/80"
                >
                  Register
                </button>
              </div>
            )}
          </nav>
        </div>
      </header>

      <AuthModal
        open={isAuthOpen}
        view={authView}
        initialEmail={undefined}
        onClose={closeAuthModal}
        onChangeView={(view) => {
          setAuthView(view);
        }}
        onAuthSuccess={() => {
          closeAuthModal();
          window.dispatchEvent(new Event("rad-auth-changed"));
        }}
      />
    </>
  );
}