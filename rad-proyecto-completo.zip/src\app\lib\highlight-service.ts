import { prisma } from "@/app/lib/prisma";
import { getDayHighlights } from "@/app/lib/wiki";
import type { HighlightItem, HighlightResponse } from "@/app/lib/rad-types";

type CachedRow = {
  day: string;
  title: string | null;
  text: string;
  image: string | null;
  articleUrl: string | null;
  year: number | null;
  type: string;
};

function mapTypeToLegacyType(rawType?: string | null): HighlightItem["type"] {
  switch (rawType) {
    case "selected":
      return "selected";
    case "event":
      return "events";
    case "birth":
      return "births";
    case "death":
      return "deaths";
    case "war":
      return "war";
    case "disaster":
      return "disaster";
    case "politics":
      return "politics";
    case "science":
      return "science";
    case "culture":
      return "culture";
    case "sports":
      return "sports";
    case "discovery":
      return "discovery";
    case "crime":
      return "crime";
    default:
      return "none";
  }
}

function inferKindFromType(rawType?: string | null): HighlightItem["kind"] {
  if (rawType === "birth") return "birth";
  if (rawType === "death") return "death";
  if (rawType === "event" || rawType === "selected") return "event";
  return "none";
}

function inferCategoryFromType(
  rawType?: string | null
): HighlightItem["category"] {
  switch (rawType) {
    case "war":
    case "disaster":
    case "politics":
    case "science":
    case "culture":
    case "sports":
    case "discovery":
    case "crime":
      return rawType;
    default:
      return "general";
  }
}

function normalizeCachedHighlight(row: CachedRow): HighlightItem {
  return {
    title: row.title,
    text: row.text,
    image: row.image,
    articleUrl: row.articleUrl,
    year: row.year,
    type: mapTypeToLegacyType(row.type),
    kind: inferKindFromType(row.type),
    category: inferCategoryFromType(row.type),
  };
}

function isNonEmptyText(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function normalizeWikiHighlightItem(item: unknown): HighlightItem | null {
  if (!item || typeof item !== "object") {
    return null;
  }

  const record = item as Record<string, unknown>;

  const text = typeof record.text === "string" ? record.text.trim() : "";
  if (!text) {
    return null;
  }

  const rawType =
    typeof record.type === "string"
      ? record.type
      : typeof record.kind === "string"
      ? record.kind
      : null;

  const rawCategory =
    typeof record.category === "string" ? record.category : null;

  const kind =
    rawType === "birth"
      ? "birth"
      : rawType === "death"
      ? "death"
      : rawType === "event" || rawType === "selected"
      ? "event"
      : "none";

  const category =
    rawCategory === "war" ||
    rawCategory === "disaster" ||
    rawCategory === "politics" ||
    rawCategory === "science" ||
    rawCategory === "culture" ||
    rawCategory === "sports" ||
    rawCategory === "discovery" ||
    rawCategory === "crime"
      ? rawCategory
      : inferCategoryFromType(rawType);

  const legacyType =
    rawType === "events" ||
    rawType === "births" ||
    rawType === "deaths" ||
    rawType === "war" ||
    rawType === "disaster" ||
    rawType === "politics" ||
    rawType === "science" ||
    rawType === "culture" ||
    rawType === "sports" ||
    rawType === "discovery" ||
    rawType === "crime" ||
    rawType === "selected" ||
    rawType === "none"
      ? (rawType as HighlightItem["type"])
      : mapTypeToLegacyType(rawType);

  return {
    title: typeof record.title === "string" ? record.title : null,
    text,
    image: typeof record.image === "string" ? record.image : null,
    articleUrl:
      typeof record.articleUrl === "string" ? record.articleUrl : null,
    year: typeof record.year === "number" ? record.year : null,
    type: legacyType,
    kind,
    category,
  };
}

function normalizeWikiHighlights(raw: unknown): HighlightItem[] {
  if (!Array.isArray(raw)) {
    return [];
  }

  return raw
    .map((item: unknown) => normalizeWikiHighlightItem(item))
    .filter((item): item is HighlightItem => item !== null);
}

function pickPrimaryHighlight(
  highlights: HighlightItem[]
): HighlightItem | undefined {
  if (highlights.length === 0) {
    return undefined;
  }

  const score = (item: HighlightItem) => {
    if (item.type === "selected") return 100;
    if (item.kind === "event") return 80;
    if (item.kind === "birth") return 60;
    if (item.kind === "death") return 50;
    if (item.type && item.type !== "none") return 40;
    return 0;
  };

  return [...highlights].sort((a, b) => score(b) - score(a))[0];
}

function getEmptyResponse(): HighlightResponse {
  return {
    highlight: {
      title: null,
      text: "No exact historical match was found for this date.",
      image: null,
      articleUrl: null,
      year: null,
      type: "none",
      kind: "none",
      category: "general",
    },
    highlights: [],
  };
}

async function readCachedHighlights(day: string): Promise<HighlightResponse | null> {
  const rows = await prisma.dayHighlightCache.findMany({
    where: { day },
    orderBy: { id: "asc" },
    select: {
      day: true,
      title: true,
      text: true,
      image: true,
      articleUrl: true,
      year: true,
      type: true,
    },
  });

  if (rows.length === 0) {
    return null;
  }

  const highlights = rows
    .map((row) => normalizeCachedHighlight(row as CachedRow))
    .filter((item) => isNonEmptyText(item.text));

  if (highlights.length === 0) {
    return getEmptyResponse();
  }

  return {
    highlight: pickPrimaryHighlight(highlights),
    highlights,
  };
}

async function writeHighlightsToCache(day: string, highlights: HighlightItem[]) {
  await prisma.dayHighlightCache.deleteMany({
    where: { day },
  });

  if (highlights.length === 0) {
    await prisma.dayHighlightCache.create({
      data: {
        day,
        title: null,
        text: "No exact historical match was found for this date.",
        image: null,
        articleUrl: null,
        year: null,
        type: "none",
      },
    });

    return;
  }

  await prisma.dayHighlightCache.createMany({
    data: highlights.map((item) => ({
      day,
      title: item.title ?? null,
      text: item.text,
      image: item.image ?? null,
      articleUrl: item.articleUrl ?? null,
      year: item.year ?? null,
      type:
        item.kind === "birth"
          ? "birth"
          : item.kind === "death"
          ? "death"
          : item.kind === "event"
          ? item.type === "selected"
            ? "selected"
            : "event"
          : item.type ?? "none",
    })),
  });
}

export async function ensureHighlightsForDay(
  day: string
): Promise<HighlightResponse> {
  const cached = await readCachedHighlights(day);

  if (cached) {
    return cached;
  }

  const rawHighlights = await getDayHighlights(day);
  const highlights = normalizeWikiHighlights(rawHighlights).filter((item) =>
    isNonEmptyText(item.text)
  );

  await writeHighlightsToCache(day, highlights);

  if (highlights.length === 0) {
    return getEmptyResponse();
  }

  return {
    highlight: pickPrimaryHighlight(highlights),
    highlights,
  };
}